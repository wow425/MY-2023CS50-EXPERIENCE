#include <stdio.h>

int main(void)
{
    int a;
    printf("a:?");
    scanf("%i", &a);
    printf("%i\n", a);
}
