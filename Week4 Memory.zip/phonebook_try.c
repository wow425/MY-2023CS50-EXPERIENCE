#include <cs50.h>
#include <stdio.h>

int main(void)
{
    char *name = get_string("name: ");
    char *numbers = get_string("numbers: ");
    FILE *file = fopen("phonebook.txt", "w");
    while (file == NULL)
    {
        return 1;
    }
    fprintf(file,"%s\n%s", name, numbers);
    fclose(file);
}
