#include <stdio.h>
#include <cs50.h>

int main(void)
{
    char *j = get_string("j: ");
    char *a = get_string("a: ");
    if (*a == *j) //若a == j的话，则是比较字符串第一个字符的地址。用*的话，就是比较第一个字符的值。
    {
        printf("equal\n");
    }
    else
    {
        printf("different");
    }
}
