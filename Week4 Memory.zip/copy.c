#include <cs50.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>

char *a;
char *b;
int main(void)
{
    do
    {
    a = get_string("a: ");
    b
    }
    while (strlen(a) <= 0 || strlen(b) <= 0);
    b = a; // 字符指针赋值是赋地址（指针，值向输入值），使a，b指向输入值。char *a;char *b
    b[0] = toupper(b[0]);
    printf("%s\n", a);
    printf("%s\n", b);
}
