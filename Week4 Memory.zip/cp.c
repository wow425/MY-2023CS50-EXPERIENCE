#include <stdio.h>
#include <stdint.h>

typedef uint8_t BYTE; //定义BYTE数据类型为无符号的8位

int main(int argc, char *argv[]) // argc 表示传递给程序的命令行数量argument count。
{                                // argv 指向字符串数组的指针数组，每个元素都指向一个命令行参数，argument vector
    FILE *dst = fopen(argv[2],"wb");  // wb 写入二进制模式 （write binary）
    FILE *src = fopen(argv[1], "rb"); // rb 读取二进制模式 r（read只读模式）b（binary二进制） 二进制模式常用于处理非文本文件，如图像、音频、视频、压缩文件等

    BYTE b;

    while (fread(&b, sizeof(b), 1, src) != 0) // fread（数据放哪（&b引用传递，b数值传递），定义每次读取的大小，读取个数，从哪读取）
    {
        fwrite(&b, sizeof(b), 1, dst); // fwrite（去哪获取数据，获取大小，获取个数，数据放哪）
    }

    fclose(dst);
    fclose(src);
}
