#include <cs50.h>
#include <stdio.h>
#include <math.h> // round搞四舍五入
#include <string.h> // https://manual.cs50.io/
#include <ctype.h>

int get_words(string text);
int main()
{
    char *text = get_string("Text: ");
    int letters = get_words(text);
    printf("%i\n", letters);
}

int get_words(string text)
{
    int sumW = 0;
    int n = strlen(text);
    for (int i = 0; i < n; i++)
    {
        if (isspace(text[i]))
        {
            sumW += 1;
        }
    }
    sumW++;
    return sumW;
}
