#include <stdio.h>
#include <cs50.h>

typedef char *string;
int main(void)
{
    string jojo = "jojoca";
    printf("%p\n", jojo); // 视为指向数组第一个元素的指针
    printf("%p\n", &jojo[0]);
    printf("%c\n", *(jojo + 1)); 指针算术，同数组一样，因为字符指针是指向字符串第一个字符的地址，可以修改地址来指向别的。
    printf("%p\n", &jojo[2]);
    printf("%p\n", &jojo[3]);
}
