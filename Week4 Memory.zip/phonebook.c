#include <cs50.h>
#include <stdio.h>
#include <string.h>

int main()
{
    FILE *file = fopen("phonebook.txt", "a");
    if (file == NULL)
    {
        return 1;
    }

    char *name = get_string("name: ");
    char *numbers = get_string("numbers: ");

    fprintf(file, "%s,%s\n", name , numbers);
    fclose(file);
}
