索引：0是索引，表示数组的第一个元素。x[0]
&  取地址运算符：获取变量内存地址
*  解引用运算符：允许取得一个地址，并前往该地址，按图索引。
例如：int a = 10; int *ptr = &a; 这里 &a 获取变量 a 的地址，并将其赋值给指针 ptr。
例如：int value = *ptr; 这里 *ptr 获取 ptr 指向的地址中的值（即 a 的值）。

%p 打印指针的值
指针 pointer 是地址，某个变量的地址,类似于寻宝图，含有某个变量的地址。int *ptr = &a; 声明指针的用法，存储地址的变量。占8字节

string jojo = "HI!";   char *jojo = "HI!"; 字符串指向第一个字符的位置，与字符指针相同。 而" "就代替&起作用，编译器自动识别""为取地址。

typedef char *string; 定义string为char *类型。

指针算术 pointer arithmetic

if (*a == *j) //若a == j的话，则是比较字符串第一个字符的地址。用*的话，就是比较第一个字符的值。

printf("%p\n", jojo); // 视为指向数组第一个元素的指针

b = a; // 字符指针赋值是赋地址（指针，值向输入值），使a，b指向输入值。char *a;char *b
    b[0] = toupper(b[0]);
    printf("%s\n", a);
    printf("%s\n", b);   使得修改值时会使a，b的值同时被修改。

库stdllib.h  standard library 函数malloc，free

函数mallo memory allocate 内存分配,用于动态分配内存，返回指向分配内存块的指针。
    a = get_string("a: ");      如果分配失败（例如，内存不足），它将返回NULL。
    b = malloc(strlen(a) + 1); // malloc指定分配n个字节，但不含有\0
    if (b == NULL) // 如果内存不足返回NULL,则终止程序。
    {
        return b;
    }
    int c = strlen(a);
    for (int i = 0; i <= c; i++) // i <= c 使得\0也能被赋给，因为malloc不包含\0
    {
        b[i] = a[i];
    }
函数free 释放指向分配内存块的指针。free(b);b = malloc(strlen(a) + 1); b = NULL;
只能释放指向分配内存块的指针。释放后，最好将指针设为NULL，以避免意外访问。
函数strcpy string copy 位于string.h库，直接实现数组值传递 strcpy(b,a); 将数组a的值传递给数组b
valgrind查看内存使用情况 valgrind ./jojo
垃圾值
函数传递按值传递（passing by reference），按副本传递
字符串只是即第一个字符的地址，即字符指针

machine code 机器代码
globals 全局变量
heap 堆 往下堆积内存块， main函数内的？
↓
↓
↓
—— 越界即发生堆溢出（heap overflow）或栈溢出(stack overflow)
↑
↑
↑
stack 栈 往上堆积内存块，main函数外的函数？

文件IO:
1. fopen 打开一个文件并返回文件指针。 FILE *file = fopen("example.txt", "r");
                                    r只读（以只读模式打开文件。如果文件不存在，则返回 NULL。）
                                    w写（以写模式打开文件。如果文件不存在，则创建该文件；如果文件存在，则会清空文件内容（覆盖写入））
                                    a（以追加模式打开文件。如果文件不存在，则创建该文件；如果文件存在，则在文件末尾添加数据，不会清空已有内容。）
                                    "r+" (读/写模式)。"w+" (读/写模式，创建/覆盖文件):。"a+" (读/写模式，追加写入):
2. fclose 关闭一个已经打开的文件。    fclose(file);
3. fread  从文件中读取数据。 int arr[10]; fread(arr, sizeof(int), 10, file);
4. fwrite 将数据写入文件。 fwrite(arr, sizeof(int), 10, file);
5. fgets  从文件中读取一行字符串。 char buffer[100]; fgets(buffer, 100, file);
6. fputs   将字符串写入文件。 fputs("Hello, World!", file);
7. fpintf  格式化输出到文件。 fprintf(file, "Number: %d\n", 42);
8. fscanf  从文件中格式化输入。int num; fscanf(file, "%d", &num); 2,3,4,5,6,7,8里的file代表FILE *类型的指针,定义类型时必须用FILE *变量名
