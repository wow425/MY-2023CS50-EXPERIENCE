#include <stdio.h>

void swap(int x, int y);
void swap1(int *x, int *y);
int main(void)
{
    int x = 1;
    int y = 2;
    printf("x=%i,y=%i\n", x, y);
    swap(x, y);
    printf("x=%i,y=%i\n", x, y);
    swap1(&x, &y);
    printf("x=%i,y=%i\n", x, y);
}

void swap(int x, int y) // 函数变量传递是按值传递，即复制内存副本给函数使用，函数用完后，该内存副本消失
{                       // 若想内存改动传递给main函数内的话，要么return返回值，要么用指针引用传递。
    int map = y;
    y = x;
    x = map;
}

void swap1(int *x, int *y) // 指针传递为引用传递，直接修改地址内的值，而非复制内存副本。
{                          // *x 获取并进入x的地址，即取x的值。
    int map = *y;
    *y = *x;
    *x = map;
}
