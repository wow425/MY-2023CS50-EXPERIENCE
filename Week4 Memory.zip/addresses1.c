#include <stdio.h>
#include <cs50.h>

int main(void)
{
    int n = 5;
    int *p = &n[0];
    printf("%i\n", *p);
}
