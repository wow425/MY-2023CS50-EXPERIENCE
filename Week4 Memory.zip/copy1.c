#include <cs50.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>

char *a;
char *b;
int main(void)
{
    do
    {
    a = get_string("a: ");
    if (a == NULL)
    {
        return a;
    }
    b = malloc(strlen(a) + 1); // malloc申请分配n个字节，但不包括\0
    if (b == NULL) // 如果内存不足返回NULL,则终止程序。
    {
        return b;
    }
    }
    while (strlen(a) <= 0 );
    int c = strlen(a);
    for (int i = 0; i <= c; i++) // i <= c 使得\0也能被赋给，因为malloc不包含\0
    {
        b[i] = a[i];
    }
    printf("%s\n", a);
    printf("%s\n", b);
}
