#include <stdio.h>
#include <cs50.h>

int main(void)
{
    string jojo = "HI!";
    printf("%p\n", jojo); // 视为指向数组第一个元素的指针
    printf("%p\n", &jojo[0]);
    printf("%p\n", &jojo[1]);
    printf("%p\n", &jojo[2]);
    printf("%p\n", &jojo[3]);
}
