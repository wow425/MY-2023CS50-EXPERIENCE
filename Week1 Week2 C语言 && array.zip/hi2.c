#include <cs50.h>
#include <stdio.h>

int main(void)
{
   string words[3];
   words[0] = "he";
   words[1] = "hi";
   printf("%c%c\n", words[0][0], words[0][1]);
   printf("%c%c",words[1][0],words[1][1]);
}
