/*
 mv重命名
 ls显示全部的文件
 rm删除文件
 cp复制
 mkdir创建目录
 rmidr删除目录
 cd切换目录
 void函数不返回任何值






*/
