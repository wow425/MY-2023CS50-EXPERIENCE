#include <cs50.h>
#include <stdio.h>

int length_name(string name);
int main(void)
{
    string name = get_string("name: ");
    int length = length_name(name);
    printf("%i\n", length);

}

int length_name(string name)
{
    int n = 0;
    while (name[n] != '\0')
    {
        n++;
    }
    return n;
}
