#include <cs50.h>
#include <stdio.h>
#include <string.h>

int main(void)
{
    string n = get_string("Input: ");
    printf("Output: ");
    int a = strlen(n);
    for (int i = 0; i < a; i++)
    {
        printf("%c", n[i]);
    }
        printf("\n");
}
