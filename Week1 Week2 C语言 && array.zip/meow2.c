#include<stdio.h>
// 用void定义某个函数来简化代码，函数右边（）内为可输入值。void为空洞，不接受输入值也不返回输出值
void meow(int n);

int main(void)
{
    meow(10);
}


 void meow(int n)
 {
    for(int i = 0; i < n; i++)
    {
        printf("meow\n");
    }
 }
