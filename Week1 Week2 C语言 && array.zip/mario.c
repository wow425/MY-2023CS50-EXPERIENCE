#include <cs50.h>
#include <stdio.h>

void walls(int w);
void space(int s);
int main(void)
{
    int N;
    do
    {
         N = get_int("height: ");
    }
    while (N < 1 || N > 8);
    for (int a = 0; a < N; a++)
    {
        space(N - a);
        walls(a + 1);
        printf("  ");
        walls(a + 1);
        printf("\n");
    }
}

void space(int s)
{
    for (int b = 0; b < s; b++)
    {
        printf(" ");
    }
}

void walls(int w)
{
    for (int c = 0; c < w; c++)
    {
        printf("#");
    }
}
