#include <cs50.h>
#include <stdio.h>

int main(void)
{
    // int jojo[3] = { 1, 2, 3 };  两种给值方法。

    // int jojo[3];
    //     jojo[0] = 1;
    //     jojo[1] = 2;
    //     jojo[2] = 3;
    // for (int i = 1; i < 4, i++)   或者用循环给值或依次输出各个小空间块的值
    // {
    //     jojo[i] =?
    // }
    //    for (int a = 0; a < 5; a++)   数组不是变量，但数组里的小空间块可视作变量.可如此赋值给其余数组
    //    {                               数组按引用传递（直接输入），变量按值传递（复印一份做输入）
    //     jojo[a] = jo[a];

}

