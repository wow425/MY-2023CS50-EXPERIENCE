#include <cs50.h>
#include <stdio.h>

int main(void)
{
    string name = get_string("name: ");
    int n = 0;
    while (name[n] != '\0')
    {
        n++;
    }length.c
    printf("%d\n", n);
}
