#include<stdio.h>

int main(void)
{
for (int count = 0; count < 3; count += 1)
{
	printf("meow\n");
}
}
/*while(true)
{
  printf("  ");
  }
此为forever循环


*/
