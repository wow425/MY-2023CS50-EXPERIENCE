#include <cs50.h>
#include <stdio.h>

int main(void)
{
   string words[3];
   words[0] = "hello";
   words[1] = "hi";
   printf("%s,%s\n", words[1], words[0]);
}
