#include <cs50.h>
#include <stdio.h>

int main(int argc, string argv[]) // argc储存命令行参数的个数。argv储存命令行的每个参数。如命令行有2个参数，argc存3个（2+1程序名）。argv[0]为程序名
{                                                                    //  argv[1]为第1个参数，argv[2]为第2个参数
    printf("hello,%s\n", argv[0]);
}
