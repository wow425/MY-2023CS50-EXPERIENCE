#include <cs50.h>
#include <stdio.h>

float average(int length, int scores[]);
const int number = 3; // 常数变量应放函数之上。
int main(void)
{
    int scores[number];
    for (int i = 0; i < number; i++)
    {
        scores[i] = get_int("scores: ");
    }
    printf("Average:%f\n", average(number, scores));
}

float average(int length, int scores[])
{
    int sum = 0;
    for (int c = 0; c < length; c++)
    {
        sum += scores[c];
    }
    return sum / (float) number;
}
