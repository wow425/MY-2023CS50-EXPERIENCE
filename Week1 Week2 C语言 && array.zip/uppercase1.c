#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main(void)
{
    string n = get_string("Before: ");
    printf("After: ");
    int a = strlen(n);
    for (int i =0; i < a; i++)
    {
        printf("%c", toupper(n[i]));
    }
        printf("\n");
}

