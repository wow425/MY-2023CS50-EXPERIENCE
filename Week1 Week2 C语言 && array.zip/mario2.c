#include<stdio.h>
#include<cs50.h>

int main(void)
{
    int n;
    do
    {
         n = get_int("size:");
    }
    while(n < 1);
    {
        n = get_int("size:");
    }
    for(int i = 0; i < n; i++)
    {
        for(int g = 0; g < n; g ++)
        {
            printf("#");
        }
            printf("\n");
    }

}
