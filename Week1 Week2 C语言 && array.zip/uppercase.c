#include <cs50.h>
#include <stdio.h>
#include <string.h>

int main(void)
{
    string n = get_string("Before: ");
    printf("After: ");
    int a = strlen(n);
    for (int i = 0; i < a; i++)
    {
        if (n[i] >= 'a' && n[i] <= 'z')  // 字符是数字
        {
            printf("%c", n[i] - 32); // 小写字母减去32就是对应大写字母的数字
        }
        else
        {
            printf("%c", n[i]);
        }
    }
}
