#include <cs50.h>
#include <stdio.h>

void wall(int b);
void space(int c);
int main(void)
{
    int N;
    do
    {
      N = get_int("height: ");
    }
    while (N < 1 || N > 8);
    for (int i = 0; i < N; i++)
    {
        space(N - i);
        wall(i + 1);
        printf("\n");
    }
}

void space(int c)
{
    for (int a = c; a > 0; a--)
    {
        printf(" ");
    }
}

void wall(int b)
{
    for (int d = 0; d < b; d++)
    {
        printf("#");
    }
}
