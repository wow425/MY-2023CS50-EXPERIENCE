#include<stdio.h>
#include<cs50.h>

int main(void)
{
   int x = get_int("x:?");
   int y = get_int("y:?");
   double z = (double) x /(double) y;//(数据类型) 变量   此为转换变量数据类型，若不转则发生遮断，即原本为0.333333却成0.000000
   printf("%.100f\n",z);//%.nf表示显示n位小数


}
