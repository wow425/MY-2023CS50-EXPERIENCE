#include <cs50.h>
#include <stdio.h>

//const int N = 3 这样的话为全局常量（对应局部变量），而非作用域
int main(void)
{
   const int N = 3 // const 即constant 常量整数 使变量值无法被更改。变量大小写无影响，但常量的话，用大写。
   int scores[N];
   for(int i = 0; i < N; i++)
   {
    scores[i] = get_int("scores: "); // 尽量以循环代替重复
   }



   printf("average: %f\n", (scores[0] + scores[1] +scores[2] ) / (float) N);//
}
