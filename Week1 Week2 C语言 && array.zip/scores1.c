#include <cs50.h>
#include <stdio.h>

int main(void)
{
   int scores[3];
       scores[0] = 72;
       scores[1] = 23;
       scores[2] = 78;



   printf("average: %f\n", (scores[0] + scores[1] +scores[2] ) / 3.0);//
}
