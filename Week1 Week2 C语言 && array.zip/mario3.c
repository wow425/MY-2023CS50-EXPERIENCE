#include<stdio.h>
#include<cs50.h>

void create_walls(int n);

int main(void)
{
   create_walls(5);
}


   void create_walls(int n)
{
    while(n < 1)
    {
        n = get_int("size:");
    }
    for(int i = 0; i < n; i++)
    {
        for(int g = 0; g < n; g ++)
        {
            printf("#");
        }
            printf("\n");
    }
}
