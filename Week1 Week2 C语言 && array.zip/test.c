#include <stdio.h>
#include <cs50.h>

int main(void)
{
    int jojo = get_int("number");
    switch (jojo)
    {
        case 12;
        printf(" ");
        break;
        case 121;
        printf(" ");
        break;
        default:
        dada;
    }
}
}
