//预引用库
#include<stdio.h>
#include<cs50.h>
 //终端"make xxxx"即编译XXX。    "./XXX" “.”为当前文件
 int main(void)
 {
 int x = get_int("what's x? ");
 int y = get_int("what's y? ");
 if(x > y)
 {
    printf("x is more than y");
 }
else if(x < y)
{
    printf("x is less than y");
}
else
{
    printf("x is equal to y");
}
   }
