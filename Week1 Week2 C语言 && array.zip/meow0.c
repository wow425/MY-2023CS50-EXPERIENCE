#include<stdio.h>

int main(void)
{
    int me = 3;
    while (me > 0)
    {
        printf("meo\n");
        me -= 1;
    }
}
