#include <cs50.h>
#include <stdio.h>
#include <string.h>

int length_name(string name);
int main(void)
{
    string name = get_string("name: ");
    int length = strlen(name); // c语言里有检验字符串长度的函数strlen，需调用string.h库
    printf("%i\n", length);

}
