/*
尽量不要让代码中出现重复内容，即冗余。
循环三语句 do while， for， while
do
    {
         n = get_int("size:");
    }
    while(n < 1);
    {
        n = get_int("size:");
    }


for(int g = 0; g < n; g ++)
        {
            printf("#");
        }

        while(n < 1)
    {
        n = get_int("size:");
    }


















*/
