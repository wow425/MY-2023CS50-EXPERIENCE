#include <cs50.h>
#include <stdio.h>

int a = 0;
int b = 0;
int c = 0;
int d = 0;
int calculate_25(int money);
int calculate_10(int money);
int calculate_5(int money);
int calculate_1(int money);
int main(void)
{
    int money;
    do
    {
        money = get_int("money: ");
    }
    while (money < 0);
    if (money >= 25)
    {
        calculate_25(money);
        money = money - (25 * a);
    }
    if (money >= 10 && money < 25)
    {
        calculate_10(money);
        money = money - (10 * b);
    }
    if (money >= 5 && money < 10)
    {
        calculate_5(money);
        money = money - (5 * c);
    }
    if (money < 5)
    {
        calculate_1(money);
    }
    printf("%d\n", a + b + c + d);
}

int calculate_25(int money)
{
    while (money >= 25)
    {
        money -= 25;
        a++;
    }
    return a;
}

int calculate_10(int money)
{
    while (money >= 10)
    {
        money -= 10;
        b++;
    }
    return b;
}

int calculate_5(int money)
{
    while (money >= 5)
    {
        money -= 5;
        c++;
    }
    return c;
}

int calculate_1(int money)
{
    while (money >= 1)
    {
        money -= 1;
        d++;
    }
    return d;
}
