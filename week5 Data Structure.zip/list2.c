// 向后添加节点

#include <stdio.h>
#include <stdlib.h>

typedef struct node
{
    int number;
    struct node *next;
}node;

int main(int argc, char *argv[])
{
    node *list = NULL;
    for (int i = 1; i < argc; i++)
    {
        node *n = malloc(sizeof(node));
        if (n == NULL)
        {
            return 1;
        }
        int number = atoi(argv[i]);
        n->number = number;
        n->next = NULL;
        if (list == NULL) // if linked list is only one node
        {
            list = n;
        }
        else // if linked list has contains multiple nodes
        {
            for (node *ptr = list; ptr != NULL; ptr = ptr->next)
            {
                // at the end of the list,append node
                if (ptr == NULL)
                {
                    ptr->next = n;
                    break;
                }
            }
        }
        // iterate over nodes in the list and print number
        for (node *ptr = list; ptr != NULL; ptr = ptr->next)
        {
            printf("%i\n", ptr->number);
        }
        // free memory
        node *ptr = list;
        while (ptr != NULL)
        {
            node *next = ptr->next;
            free(ptr);
            ptr = next;
        }
    }
}
