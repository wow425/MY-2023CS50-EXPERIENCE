队列（Queue）是一种典型的线性数据结构，遵循**先进先出（FIFO, First In First Out）**的原则。这意味着最早插入的数据会最早被取出，像排队一样。

栈（Stack）是一种线性数据结构，遵循后进先出（LIFO, Last In First Out）的原则。这意味着最后插入的数据最先被取出。与队列不同，栈只允许在一端进行操作——即栈顶。

链表（Linked List）是一种动态数据结构，由一系列节点（Node）组成，这些节点通过指针连接在一起。
与数组不同，链表中的元素在内存中不需要是连续的。链表的每个节点都包含两个部分：

typedef struct node
{
    int number;
    struct node *next;  因为编译器从上往下读，若想定义node类型的结构体则必须在struct后+ node。 此后用node就行
}node;

node *n = alloc(sizeof(node));
n->number = number;
-> 操作符：在 C 语言中，-> 用于通过指向结构体的指针访问结构体的成员。等价于 (*n).number，但更简洁。

树(tree)
树是一种分层的数据结构，由节点（node）和边（edge）组成，通常用于表示具有层次关系的数据。树具有以下特点：
根节点（Root Node）：树的起点。树中唯一的一个根节点没有父节点。
节点（Node）：每个节点包含数据以及指向其子节点的指针。一个节点可以有零个或多个子节点。
叶节点（Leaf Node）：没有子节点的节点，位于树的底部。
父节点与子节点（Parent and Child Nodes）：每个节点都有可能指向其下层的节点，称为子节点；与之对应的上层节点称为父节点。
边（Edge）：连接父节点和子节点的连接线。
树的常见类型包括：
二叉树（Binary Tree）：每个节点最多有两个子节点（左子节点和右子节点）。
二叉搜索树（Binary Search Tree, BST）：一种特殊的二叉树，左子树的节点值小于父节点，右子树的节点值大于父节点。
平衡树：如AVL树、红黑树等，通过控制树的高度，保证操作的时间复杂度尽量接近O(log n)。

字典(dictionaries) 键(key) 值(value) 散列(hashing) 哈希表(hash table)
前缀树(trie, retrieval检索)  为数组树
