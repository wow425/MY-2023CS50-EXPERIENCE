#include <stdio.h>
#include <stdlib.h>
 // 往前插入节点
typedef struct node
{
    int number;
    struct node *next;
}node;
int main(int argc, char *argv[])
{
    node *list = NULL;
    // link node
    for (int i = 1; i < argc; i++)
    {
        int number = atoi(argv[i]);
        node *n = malloc(sizeof(node));
        if (n == NULL)
        {
            return 1;
        }
        n->number = number;
        n->next = list;
        list = n;
    }
    // print number
    node *ptr = list;
    while (ptr != NULL)
    {
        printf("%i ", ptr->number);
        ptr = ptr->next;
    }
    // for (node *ptr = list; ptr != NULL; ptr = ptr->next ) //遍历节点的两种方法
    // {
    //     printf("%d ", ptr->number);
    // }
    // free memory
    while (ptr != NULL)
    {
        list = ptr->next;
        free(ptr);
        ptr = list;
    }
}
