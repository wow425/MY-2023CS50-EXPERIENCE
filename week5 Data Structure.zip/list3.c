#include <stdio.h>
#include <stdlib.h>

typedef struct node
{
    int number;
    struct node *next;
}
node;

int main (int argc, char *argv[])
{
    node *list = NULL;
    for (int i = 1; i < argc; i++)
    {
        int number = atoi(argv[i]);
        node *n = malloc(sizeof(node));
        if (n == NULL) // 只要调用malloc必检验是否申请成功
        {
            return 1;
        }
        n->number = number;
        n->next = NULL;
        if (list == NULL) // if empty list
        {
            list = n;
        }
        else if (n->number < list->number) // if node belongs at beginning of  list
        {
            n->next = list;
            list = n;
        }
        else // if node belongs later in list
        {
            for (node *ptr = list; ptr != NULL; ptr = ptr->next) // iterate whole list
            {
                // break使节点插入结束后终止循环，否则会完成遍历，使链表结构错误
                if (ptr->next == NULL) // if node is at end of list
                {
                    ptr->next = n;
                    break;
                }
                if (n->number < ptr->next->number) // if node is in middle of list
                {
                    n->next = ptr->next;
                    ptr->next = n;
                    break;
                }
            }
        }
    }
    // iterate whole list and print
    for (node *ptr = list; ptr != NULL; ptr = ptr->next)
    {
        printf("%i ", ptr->number);
    }
    // free memory
    node *ptr = list;
    while (ptr != NULL)
    {
        ptr = ptr->next;
        free(list);
        list = ptr;
    }
}
