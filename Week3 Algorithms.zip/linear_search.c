#include <cs50.h>
#include <stdio.h>

int main(void)
{
    int number[] = {20, 500, 10, 5, 100, 1, 50};
    int n = get_int("number: ");
    for (int i = 0; i < 7; i++)
    {
        if (number[i] == n)
        {
            printf("FOUND\n");
            return 0; // return 整数 使main函数终止.没有设置返回整数的话就会向下执行完才行
        }             // 就是return+整数终止main函数
    }
    printf("NOTFOUND\n");
    return 1;

}
