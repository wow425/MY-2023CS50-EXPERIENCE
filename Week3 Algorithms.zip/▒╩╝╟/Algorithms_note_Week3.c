数组是一系列连续值的集合，要求同一数据类型
线性搜索： 一条线式的搜索方式
二分搜索： 取半，往左或往右再取半
大O表示法： 大O表示法（Big O Notation） 是一种用于分析算法的时间复杂度和空间复杂度的数学表示方式。它主要用来描述算法在最坏情况下的性能，即随着输入规模的增加，算法的运行时间或占用空间的增长率。大O表示法为算法效率提供了一个定量的方式，使我们能更好地理解不同算法在处理相同规模的问题时的表现。
大O表示法的要点：
最坏情况：大O通常表示算法在输入规模最大或最复杂时的性能，因此它强调最坏情况下的运行时间或空间使用。
表示增长率：大O关注的是当输入规模逐渐增大时，运行时间或空间需求的增长趋势，而不是具体的运行时间。
忽略常数：大O只关心增长的速度，而不关心算法中常数或低阶项。例如，时间复杂度为 O(2n) 和 O(n) 实际上被视为相同，表示其增长率是线性的（O(n)）。
常见的大O时间复杂度
O(1)（常数时间）：算法的运行时间与输入大小无关，始终执行相同数量的操作。
示例：访问数组中某个元素。

O(log n)（对数时间）：算法的运行时间随着输入大小的增长而以对数速度增长。
示例：二分查找。

O(n)（线性时间）：算法的运行时间与输入大小成正比。
示例：遍历一个长度为n的列表。

O(n log n)（线性对数时间）：常见于高效排序算法，如归并排序和快速排序的平均情况。
示例：归并排序。Merge sort

O(n²)（平方时间）：运行时间与输入大小的平方成正比，通常表示嵌套循环的算法。
示例：冒泡排序、插入排序,选择排序（Selection sort）

O(2^n)（指数时间）：算法的运行时间随着输入大小指数级增长，常见于解决组合问题的递归算法。
示例：解决“汉诺塔问题”或递归实现的斐波那契数列。

O(n!)（阶乘时间）：运行时间随着输入大小的阶乘增长。
示例：求解旅行商问题的暴力解法。

在最坏情况下，算法必须检查数组中的每个元素，因此时间复杂度为O(n)（线性时间），因为每次输入规模 n 增加时，检查的次数也成比例增加。

大O表示法的意义
大O帮助我们预测算法在面对大规模输入时的表现，并使我们能够比较不同算法的效率，选择在特定场景下更高效的算法。这种表示法虽然忽略了常数和低阶项，但为程序员提供了一个有力的工具来设计和优化算法。
==等于运算符只能比较数字，如果要检验字符串是否等于的话，

在计算机科学与技术中，θ（Theta）符号用于描述算法的渐进复杂度，特别是它的运行时间或空间复杂度的紧确界限。形式上，θ符号定义为：
这意味着一个算法的复杂度在某个范围内既不低于（下界）也不高于（上界）函数
因此提供了算法性能的确切描述。
使用 θ 符号的主要作用包括：
精确性：能够准确描述算法的增长率。
比较：在比较不同算法时，提供了一种标准化的方法。
分析：帮助分析算法在最坏、最好和平均情况下的性能。      θ评判渐进性能，在下界与上界内的性能。

二分搜索 Binary search:
If no doors left
      Return false
If number behind middle door
      Return true
Else if number < middle door
      Search left half
Else if number > middle door
      Search right half

选择排序 Selection sort：  
一遍又一遍查找最小数字并放在最左或右边 n！
For i from 0 to n-1
   Find smallest number between number[i] and numbers[n-1]
   Swap smallest number with numbers[i]

冒泡排序 Bubble sort:    1，4，3，2，8，4，9，0——————0，1，2，3，4，4，8，9
一遍遍地比较两值大小并交换。
Repeat n-1 times  (n-1因为最后一个数字不需要bubble)
    For i from 0 to n-2   （n-2因为最后一个数字不需要bubble且从0开始）
        If numbers[i] and numbers[i+1] out of order
           Swap them
        If no swaps
           Quit

归并排序 Merge sort：
If only one number
   Quit
Else
    Sort left half of numbers
    Sort right half of numbers
    Merge sorted halves


调用string.h库里的strcmp函数
 if (strcmp(numbers[], string) == 0) str compare
 原理：用ASCII将字符转换为数字来比较
 此为使用方法 比较number[]与某字符串，最终输出0(true)或1(false)

结构体 定义类型 创建自己的数据类型和变量
 typedef struct
{
    string name;
    string number;
}
point;
int main(void)
{
    point people[3];
    people[0].name = "jojo";
    people[0].number = "12345";
    people[1].name = "dio";
    people[1].number = "666";
    people[2].name = "saber";
    people[2].number = "75634";

    if (strcmp(people[i].name, name) == 0)
        {
            printf("%s\n", people[i].number);
            return 0;

如果输入值带有，的话，那么scanf无法将里面的值正确传递给数组变量，但变量可以。如要用数组接收带有逗号的输入值的话，用循环语句依次接收。
    scanf("%d %d %d %d %f", &a[0], &b, &c, &d, &e);     scanf("%d %d %d %d %f", &a, &b, &c, &d, &e);

在 C 语言中，参数传递的方式主要有两种：值传递（pass by value）和引用传递（pass by reference）。下面是这两种方式的具体说明，以及对数组的处理方式。

值传递（Pass by Value）
定义：当你将一个变量作为参数传递给函数时，实际上传递的是该变量的副本。在函数内部对该副本的任何修改不会影响原始变量。
示例：
c
复制代码
void function(int a) {
    a = 10; // 只修改副本
}

int main() {
    int x = 5;
    function(x);
    printf("%d\n", x); // 输出 5，原始变量未改变
    return 0;
}
引用传递（Pass by Reference）
定义：当你将一个变量的地址（指针）作为参数传递给函数时，你实际上是允许函数直接访问和修改原始变量。这样对参数的修改会影响原始变量。
示例：
c
复制代码
void function(int *a) {
    *a = 10; // 修改原始变量
}

int main() {
    int x = 5;
    function(&x);
    printf("%d\n", x); // 输出 10，原始变量被修改
    return 0;
}
数组的传递
数组作为参数：在 C 语言中，当你将一个数组作为参数传递给函数时，实际上传递的是数组的首地址（即指向数组第一个元素的指针）。因此，在函数内对数组元素的修改会影响原始数组。
示例：
c
复制代码
void modifyArray(int arr[], int size) {
    for (int i = 0; i < size; i++) {
        arr[i] += 1; // 修改原数组
    }
}

int main() {
    int myArray[] = {1, 2, 3};
    modifyArray(myArray, 3);
    printf("%d\n", myArray[0]); // 输出 2，原数组被修改
    return 0;
}
总结
基本变量（如 int, float 等）：是值传递，传递的是变量的副本。
数组：作为参数传递时，实际上是传递了数组的指针，允许函数修改原数组的内容。
结构体：如果按值传递，传递的是结构体的副本；如果按指针传递，允许修改原结构体。

递归是通过函数自身调用来解决问题，通常适合于分治法和树结构等场景，代码简洁但可能导致栈溢出；迭代则是通过循环反复执行操作，更加节省内存，适合处理大规模数据。两者在逻辑上可以相互转换，但在性能和易读性上各有优劣。

递归的例子是计算阶乘：recurison 调用自身函数

int factorial(int n) {
    if (n == 0) return 1;
    return n * factorial(n - 1);
}
迭代的例子也是计算阶乘：iteration 循环反复执行操作

int factorial(int n) {
    int result = 1;
    for (int i = 1; i <= n; i++) {
        result *= i;
    }
    return result;
}



















