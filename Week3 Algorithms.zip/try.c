#include <cs50.h>
#include <stdio.h>
#include <string.h>

typedef struct
{
    string number;
    string name;
}
point;
int main()
{
    point person[3];
    person[0].number = "123";
    person[0].name = "jojo";
     person[1].number = "12366";
    person[1].name = "ko";
     person[2].number = "12342";
    person[2].name = "no";
    string name = get_string("name: ");
    for (int i = 0;i < 3; i++)
    {
        if (strcmp(person[i].name, name) == 0)
        {
            printf("%s\n", person[i].number);
            return 0;
        }
    }
    printf("NOTFOUND\n");
    return 1;
}
