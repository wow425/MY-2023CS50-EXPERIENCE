#include <cs50.h>
#include <stdio.h>
// iteraction 迭代
void draw (int n);
int main(void)
{
    int n = get_int("height: ");
    draw(n);
}

void draw (int n)
{
    for (int i = 0; i < n; i++)
    {
        for (int a = 0; a < i + 1; a++)
        {
            printf("#");
        }
        printf("\n");
    }
}
