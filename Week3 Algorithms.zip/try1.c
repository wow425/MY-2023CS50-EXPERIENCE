#include <stdio.h>
#include <cs50.h>

int factorial(int n);
int main(void)
{
		int a = get_int("?");
		printf("%d",factorial(a));


}

	int factorial(int n) 
{
    if (n == 0) return 1;
    return n * factorial(n - 1);
}
