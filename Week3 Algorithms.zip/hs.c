#include <stdio.h>

float score[5];
float average(float n[]);
int main(void)
{
    printf(" ");
    scanf("%f， %f， %f， %f， %f", &score[0], &score[1], &score[2], &score[3], &score[4]); // 数组没法直接用于计算。改循环接收，带逗号的输入值无法正确传递给数组变量
    printf("平均分：%.2f\n", average(score));

    return 0;
}

float average(float n[])
{
    float sum = 0;
    for (int i = 0; i < 5; i++)
    {
        sum += n[i];
    }
    return sum / 5.0;
}
