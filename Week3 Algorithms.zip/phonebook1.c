#include <cs50.h>
#include <stdio.h>
#include <string.h>

typedef struct
{
    string name;
    string number;
}
point;
int main(void)
{
    point people[3];
    people[0].name = "jojo";
    people[0].number = "12345";
    people[1].name = "dio";
    people[1].number = "666";
    people[2].name = "saber";
    people[2].number = "75634";
    string name = get_string("name: ");
    for (int i = 0;i < 3; i++)
    {
        if (strcmp(people[i].name, name) == 0)
        {
            printf("%s\n", people[i].number);
            return 0;
        }
    }
    printf("NOTFOUND\n");
    return 1;
}
