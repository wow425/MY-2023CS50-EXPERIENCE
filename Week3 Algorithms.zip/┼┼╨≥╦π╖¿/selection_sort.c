#include <stdio.h>

// 选择排序 Selection sort：
// 一遍又一遍查找最小数字并放在最左或右边 n！
// For i from 0 to n-1
//    Find smallest number between number[i] and numbers[n-1]
//    Swap smallest number with numbers[i]

void selection_sort(int numbers[], int n);
int main()
{
    int numbers[] = {5, 2, 7, 4, 1, 6, 3, 0};
    selection_sort(numbers, 8);
    for (int i = 0; i < 8; i++)
    {
        printf("%d ", numbers[i]);
    }
}

void selection_sort(int numbers[], int n)
{
    for (int i = 0; i <= n-1; i++) //外for实现n次检阅最小数
    {
       int min = i; //
        for (int j = i + 1; j <= n - 1; j++)
        {
            if (numbers[j] < numbers[min])  // 遍历查找最小数
            {
                min = j;
            }
        }
        int temp = numbers[min];  // 实现最小数与当前位置交换
        numbers[min] = numbers[i];
        numbers[i] = temp;
    }
}
