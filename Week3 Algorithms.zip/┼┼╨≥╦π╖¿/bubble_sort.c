#include <stdio.h>

//  冒泡排序 Bubble sort:    1，4，3，2，8，4，9，0——————0，1，2，3，4，4，8，9
// 一遍遍地比较两值大小并交换。
// Repeat n-1 times  (n-1因为最后一个数字不需要bubble)
//     For i from 0 to n-2   （n-2因为最后一个数字不需要bubble且从0开始）
//         If numbers[i] and numbers[i+1] out of order
//            Swap them
//         If no swaps
//            Quit

void bubble_sort(int numbers[], int n);
int main()
{
    int numbers[] = {5, 2, 7, 4, 1, 6, 3, 0};
    bubble_sort(numbers, 8);
    // merge_sort{numbers, 8, 0 ,7};
    for (int i = 0; i < 8; i++)
    {
        printf("%d", numbers[i]);
    }
}

void bubble_sort(int numbers[], int n)
{
    int is_swap = 0;
    while (n-1 > 0)
    {
        for (int i = 0; i <= n-2; i++)
        {
            if (numbers[i] > numbers[i + 1])
            {
                int temp = numbers[i];
                numbers[i] = numbers[i + 1];
                numbers[i + 1] = temp;
                is_swap = 1;
            }
        }
        if (is_swap == 0)
        {
            return 1;
        }
        n --;
    }
}
