/*
关于编译器：
第一种用make：make hello。./hello
第二种直接用clang编译器：make hello，此时默认创建为a.out的c文件，需要用clang -o hello a.out来改名，再./hello。
                    即：make hello。clang -o hello a.out。./hello。
                    若需要调用第三方库：clang -o hello hello.c -lcs50（-l为调库）
编程语言转换为机器语言四步
1.预处理:即#include <cs50.h>  编译器找cs50.h头文件并复制粘贴到代码中。 执行查找和替换
2.编译：将源代码转换为汇编代码
3.汇编：编译为二进制
4.链接：被调用的库的文件和代码文件转换为二进制后，被合并成一个文件，默认名为a.out

printf("i is %i\n", i)； 看变量i的值
调试器指令：debug50 文件名
运算中带浮点数的话，就变成浮点数学运算

数组array int scores[3];    数组的值放在内存块相邻无间隔的位置 数组即给个大小为3的数组，位置0，1,2放对应的值。 给scores变量放3个值
             scores[0] = 72
             scores[1] = 21
             scores[2] = 12


在内存中，一个字符串占一块位置，如有5个字符的字符串就占5个格子，每个格子存放1个字符，既可以通过%i打印出该字符对应的数字，也可以通过%c打印出该字符。

 string words[3];
   words[0] = "he";
   words[1] = "hi";
   printf("%c%c\n", words[0][0], words[0][1]);   字符串数组words有3个格子，第1个格子给了he，第2个格子给了hi
   printf("%c%c",words[1][0],words[1][1]);       第1个格子又有2个小格子h和e，words[0][0], words[0][1]就是对应的位置。
}

do
    {
      N = get_int("height: ");
    }
    while (N < 1 || N > 8);

!= 为不等于运算符。a为1， b为2, a != b 为true。它是一个关系运算符，用于比较两个值。如果左边的值与右边的值不相等，表达式的结果为真（即 1），否则结果为假（即 0）

在 C 语言中，while (name[n] != '\0') 这行代码的意思是循环遍历字符串 name，直到遇到字符串的结束符 '\0' 为止。

解释：

name[n] 表示数组 name 中的第 n 个空间
'\0' 是 C 语言中字符串的结束符，表示字符串的末尾。
这个循环通常用于逐字符处理字符串。循环条件 name[n] != '\0' 意味着只要当前字符不是结束符，就继续执行循环体中的代码。每次循环后，通常会更新 n 的值来遍历下一个字符。

一个常见的设计模式是迭代器模式，它在遍历数据结构时很常用。这个 while 循环就是一种简单的迭代方式，用来遍历字符数组（字符串）。
c语言里有检验字符串长度的函数strlen，需调用string.h库 string length 参数为string
c语言里有自动小写字母转大写字母的函数toupper，需调用ctype.h库 参数为char
#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main(void)
{
    string n = get_string("Before: ");
    printf("After: ");
    int a = strlen(n);
    for (int i =0; i < a; i++)
    {
        printf("%c", toupper(n[i]));
    }
        printf("\n");
}

条件语句switch用法:
switch (表达式)：

switch 后面的表达式会被计算出一个值，通常是整数类型（如 int 或 char），然后将其与每个 case 后的常量进行比较。
表达式的值可以是变量、常量或复杂的表达式，但通常是一个变量。
case 常量：

每个 case 后面跟着一个常量值，表示当 switch 表达式的值等于该常量时，将执行相应的语句块。
常量可以是整数、字符等，但不能是范围、浮点数或者其他数据类型。
break：

break 语句用于终止当前 case 中的执行，跳出 switch 结构，防止继续执行后面的 case。
如果没有 break，程序将继续执行下一个 case 中的代码，直到遇到 break 或到达 switch 结构的末尾。这种行为称为**"fall through"**。
default：

default 是一个可选的分支，用于处理所有不匹配任何 case 常量的情况。如果 switch 表达式的值与所有 case 的常量都不匹配，就会执行 default 中的语句块。
default 类似于 if-else 语句中的 else，表示"其他情况"。
int main(void)
{
    int jojo = get_int("number");
    switch (jojo)
    {
        case 258:
        printf("258\n");
        break;
        case 259:
        printf("259\n");
        break;
        default:
        printf("257\n");

    }
}






*/
