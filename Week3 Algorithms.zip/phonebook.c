#include <cs50.h>
#include <stdio.h>
#include <string.h>

int main(void)
{
    string numbers[] = {"jojo", "dio", "kono"};// array存数据
    string phones[] = {"132-1312", "1512-76655", "1311-634"};
    string name = get_string("name: ");
    for (int i = 0;i < 3; i++)
    {
        if (strcmp(numbers[i], name) == 0)
        {
            printf("%s\n", phones[i]);
            return 0;
        }
    }
    printf("NOTFOUND\n");
    return 1;
}
