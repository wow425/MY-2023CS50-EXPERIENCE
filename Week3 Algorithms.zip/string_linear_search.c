#include <cs50.h>
#include <stdio.h>
#include <string.h>

int main()
{
    string numbers[] = {"battleship", "boot", "cannon", "iron", "thimble", "top hat"};

    string n = get_string("number: ");
    for (int i = 0; i < 6; i++)
    {
        if (strcmp(numbers[1], n) == 0)
        {
            printf("FOUND\n");
            return 0;
        }
    }
    printf("NOTFOUND\n");
    return 1;
}
