bool check_duplicate(string key)
{
    int jojo[26] = {0};
    for (int d = 0; d < 26; d++)
    {
        char c = tolower(key[d]);
        while (jojo[c - 'a'] > 0)
        {
            return true;
        }
        jojo[c - 'a']++;
    }
    return false;
}
