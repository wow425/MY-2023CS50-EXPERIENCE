#include <cs50.h>
#include <ctype.h>
#include <stdio.h>
#include <string.h>

string p1, p2;
int uppercase(string u, int *sum);
int main(void)
{


    p1 = get_string("Player1: ");
    p2 = get_string("Player2: "); // 字符串本身就是数组，是字符的集合。 // switch函数来实现根据字母种类来赋值。toupper函数实现小写转大写。
    int sum1 = 0;
    int sum2 = 0;
    uppercase(p1, &sum1);
    uppercase(p2, &sum2); // 转大写字母。
    // 比较sum

     if (sum1 > sum2)
     {
        printf("Player 1 wins!");
     }
     else if (sum1 < sum2)
     {
        printf("Player 2 wins!");
     }
     else
     {
        printf("Tie!");
     }




}

int uppercase(string u, int *sum) // 传递sum地址，而不是变量的给值传递和
{
   int n = strlen(u);
   for (int i = 0; i < n; i++)
   {
    u[i] = toupper(u[i]);
   }
   // 字符匹配,并sum
   for (int a = 0; a < n; a++)
   {
    switch (u[a])
    {
        case 'A':
        case 'L':
        case 'I':
        case 'E':
        case 'N':
        case 'O':
        case 'R':
        case 'S':
        case 'T':
        case 'U':
        *sum += 1;
        break;

        case 'D':
        case 'G':
        *sum += 2;
        break;

        case 'C':
        case 'B':
        case 'M':
        case 'P':
        *sum += 3;
        break;

        case 'H':
        case 'F':
        case 'V':
        case 'W':
        case 'Y':
        *sum += 4;
        break;

        case 'K':
        *sum += 5;
        break;

        case 'X':
        case 'J':
        *sum += 8;
        break;

        case 'Z':
        case 'Q':
        *sum += 10;
        break;
    }
   }
   return *sum;
}




