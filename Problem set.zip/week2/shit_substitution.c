#include <cs50.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>

bool check_duplicate(string key);
bool check_alpha(string alpha);
char encrypt(char plaintext, string key);
int main(int argc, char *argv[])
{
    if (argc != 2 || strlen(argv[1]) != 26)
    {
        printf("Key must contain 26 characters.\n");
        return 1;
    }
    if (check_alpha(argv[1]))
    {
        printf("Usage: ./substitution key\n");
        return 1;
    }
    if (check_duplicate(argv[1]))
    {
        printf("Key must not contain duplicate characters.\n");
        return 1;
    }

    char *plaintext = get_string("plaintext:  ");
    char *ciphertext = malloc(strlen(plaintext) + 1);
    int n = strlen(plaintext);
    for (int i = 0; i < n; i++)
    {
        ciphertext[i] = encrypt(plaintext[i], argv[1]);
    }
    ciphertext[(strlen(plaintext) + 1)] = '\0';

    printf("ciphertext: %s\n", ciphertext);
}

bool check_alpha(string alpha)
{
    for (int a = 0; a < 26; a++)
    {
        while (!isalpha(alpha[a]))
        {
            return true;
        }
    }
    return false;
}

char encrypt(char plaintext, string key)
{
    if (isupper(plaintext))
    {
        switch (plaintext)
        {
 case 'A':
    return toupper(key[0]);
    case 'B':
    return toupper(key[1]);
    case 'C':
    return toupper(key[2]);
    case 'D':
    return toupper(key[3]);
    case 'E':
    return toupper(key[4]);
    case 'F':
    return toupper(key[5]);
    case 'G':
    return toupper(key[6]);
    case 'H':
    return toupper(key[7]);
    case 'I':
    return toupper(key[8]);
    case 'J':
    return toupper(key[9]);
    case 'K':
    return toupper(key[10]);
    case 'L':
    return toupper(key[11]);
    case 'M':
    return toupper(key[12]);
    case 'N':
    return toupper(key[13]);
    case 'O':
    return toupper(key[14]);
    case 'P':
    return toupper(key[15]);
    case 'Q':
    return toupper(key[16]);
    case 'R':
    return toupper(key[17]);
    case 'S':
    return toupper(key[18]);
    case 'T':
    return toupper(key[19]);
    case 'U':
    return toupper(key[20]);
    case 'V':
    return toupper(key[21]);
    case 'W':
    return toupper(key[22]);
    case 'X':
    return toupper(key[23]);
    case 'Y':
    return toupper(key[24]);
    case 'Z':
    return toupper(key[25]);
     }
    }
    else if (islower(plaintext))
   {switch (plaintext)
    {
    case 'a':
    return tolower(key[0]);
    case 'b':
    return tolower(key[1]);
    case 'c':
    return tolower(key[2]);
    case 'd':
    return tolower(key[3]);
    case 'e':
    return tolower(key[4]);
    case 'f':
    return tolower(key[5]);
    case 'g':
    return tolower(key[6]);
    case 'h':
    return tolower(key[7]);
    case 'i':
    return tolower(key[8]);
    case 'j':
    return tolower(key[9]);
    case 'k':
    return tolower(key[10]);
    case 'l':
    return tolower(key[11]);
    case 'm':
    return tolower(key[12]);
    case 'n':
    return tolower(key[13]);
    case 'o':
    return tolower(key[14]);
    case 'p':
    return tolower(key[15]);
    case 'q':
    return tolower(key[16]);
    case 'r':
    return tolower(key[17]);
    case 's':
    return tolower(key[18]);
    case 't':
    return tolower(key[19]);
    case 'u':
    return tolower(key[20]);
    case 'v':
    return tolower(key[21]);
    case 'w':
    return tolower(key[22]);
    case 'x':
    return tolower(key[23]);
    case 'y':
    return tolower(key[24]);
    case 'z':
    return tolower(key[25]);
     }
    }
 return plaintext;
}

bool check_duplicate(string key)
{
    int freq[26] = {0}; // 用于记录每个字母的频率

    for (int i = 0; i < 26; i++)
    {
        char c = tolower(key[i]); // 将字母转换为小写以避免区分大小写
        if (freq[c - 'a'] > 0)    // 如果该字母已经出现过
        {
            return true; // 表示有重复字母
        }
        freq[c - 'a']++; // 记录该字母出现的次数
    }
    return false;
}
