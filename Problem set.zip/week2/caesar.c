#include <stdio.h>
#include <cs50.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

bool check_digit(string c);
char rotate(char c, int key);
int main(int argc, char *argv[])
{
    if (argc != 2 || !check_digit(argv[1]))
    {
        printf("Usage: ./caesar key\n");
        return 1;
    }
    char *plaintext = get_string("plaintext:  ");
    char *ciphertext = malloc(strlen(plaintext) + 1);
    for (int i = 0; i < strlen(plaintext) + 1; i++)
    {

        ciphertext[i] = rotate(plaintext[i], atoi(argv[1]));
    }
    printf("ciphertext: %s\n", ciphertext);
    free(ciphertext);
}
 
char rotate(char c, int key)
{
    int l = 0;
    if (isalpha(c))
    {
        if (isupper(c))
        {
            l = (c - 'A' + key) % 26 + 'A';
            return l;
        }
        else
        {
            l = (c - 'a' + key) % 26 + 'a';
            return l;
        }
    }
    else
    {
        return c;
    }
}

bool check_digit(string c)
{
    for (int i = 0; i < strlen(c); i++)
    {
        if (!isdigit(c[i]))
        {
            return false;
        }
    }
    return true;
}
