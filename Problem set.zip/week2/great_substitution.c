#include <cs50.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>

bool check_duplicate(string key);
bool check_alpha(string alpha);
char encrypt(char plaintext, string key);
int main(int argc, char *argv[])
{
    if (argc != 2 || strlen(argv[1]) != 26)
    {
        printf("Key must contain 26 characters.\n");
        return 1;
    }
    if (check_alpha(argv[1]))
    {
        printf("Usage: ./substitution key\n");
        return 1;
    }
    if (check_duplicate(argv[1]))
    {
        printf("Key must not contain duplicate characters.\n");
        return 1;
    }

    char *plaintext = get_string("plaintext:  ");
    char *ciphertext = malloc(strlen(plaintext) + 1);
    int n = strlen(plaintext);
    for (int i = 0; i < n; i++)
    {
        ciphertext[i] = encrypt(plaintext[i], argv[1]);
    }
    ciphertext[(strlen(plaintext) + 1)] = '\0';

    printf("ciphertext: %s\n", ciphertext);
}

bool check_alpha(string alpha)
{
    for (int a = 0; a < 26; a++)
    {
        while (!isalpha(alpha[a]))
        {
            return true;
        }
    }
    return false;
}

char encrypt(char plaintext, string key)
{
    if (isupper(plaintext))
    {
        return toupper(key[plaintext - 'A']);
    }
    else if (islower(plaintext))
    {
        return tolower(key[plaintext - 'a']);
    }
    return plaintext;
}

bool check_duplicate(string key)
{
    int jojo[26] = {0};
    for (int d = 0; d < 26; d++)
    {
        char c = tolower(key[d]);
        while (jojo[c - 'a'] > 0)
        {
            return true;
        }
        jojo[c - 'a']++;
    }
    return false;
}
