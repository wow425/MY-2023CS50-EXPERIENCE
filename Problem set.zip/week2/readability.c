#include <cs50.h>
#include <stdio.h>
#include <math.h> // round搞四舍五入
#include <string.h> // https://manual.cs50.io/
#include <ctype.h>

int get_letters(string text);
int get_words(string text);
int get_sentences(string text);
int main()
{
    char *text;
    do
    {
        text = get_string("Text: ");
    }
    while (strlen(text) <= 0);
    int letters = get_letters(text);
    int words = get_words(text);
    int sentences = get_sentences(text);

    float L = letters / (float) words * 100;
    float S = sentences / (float) words * 100;
    double index = 0.0588 * L - 0.296 * S - 15.8;
    index = round(index); // 四舍五入用，math库函数
    if (index >= 16)
    {
        printf("Grade 16+\n");
    }
    else if (index < 16 && index >= 1)
    {
        printf("Grade %0.f\n", index);
    }
    else
    {
        printf("Before Grade 1\n");
    }
}

int get_letters(string text) // 只有大小写字母才算字母
{
    int sumL = 0;
    int n = strlen(text);
    for (int i = 0; i < n; i++)
    {
        if (isalpha(text[i])) // if条件语句，满足条件就执行一次。而while循环语句，满足条件就不断循环直至不满足条件。
        {                 // isalpha ctype库函数 检验该字符是否为大小写的字母。
            sumL += 1;
        }
    }
    return sumL;
}

int get_words(string text)
{
    int sumW = 0;
    int n = strlen(text);
    for (int i = 0; i < n; i++)
    {
        if (isspace(text[i])) // 找单词个数，看空格数量
        {
            sumW += 1;
        }
    }
    sumW++;
    return sumW;
}

int get_sentences(string text)
{
    int sumS = 0;
    int n = strlen(text);
    for (int i = 0; i < n; i++)
    {
        if (text[i] == '.' || text[i] == '!' || text[i] == '?')
        {
            sumS += 1;
        }
    }
    return sumS;
}
