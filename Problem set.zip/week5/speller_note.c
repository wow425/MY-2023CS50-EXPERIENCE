strcpy string.h
原型为：char *strcpy(char *dest, const char *src);
strcpy 的工作原理：
传递两个参数：函数接收两个参数，src 是源字符串，dest 是目标字符数组（或指针），将 src 的内容复制到 dest。
逐字符复制：函数会从 src 开始，逐个字符地复制到 dest，直到遇到字符串结束标志 '\0'（空字符）。
添加终止符：复制完成后，dest 中的最后一个字符将被赋值为 '\0'，以确保目标字符串也是以空字符结尾。
返回值：strcpy 返回的是目标地址 dest，用于链式调用或其他处理。
char src[] = "Hello, World!";
char dest[20];  // 确保目标数组足够大
strcpy(dest, src);  // 将 src 复制到 dest
printf("Copied string: %s\n", dest);


fscanf stdio.h
int fscanf(FILE *stream, const char *format, ...);
参数说明：
FILE *stream：表示文件指针，指向需要读取的文件。
const char *format：格式化字符串，用于指定读取的数据类型，如 %d、%s、%f 等。
...：可变参数，用于接收读取到的数据。
返回值：
返回成功读取的数据项个数。
如果遇到文件结束或读取出错，返回 EOF（通常为 -1）。
    // 打开文件读取数据
    int age;
    char name[50];
    FILE *file = fopen("data.txt", "r");
    if (file == NULL) {
        printf("无法打开文件。\n");
        return 1;
    }
    // 从文件中读取格式化数据
    while (fscanf(file, "%s %d", name, &age) != EOF) {
        printf("Name: %s, Age: %d\n", name, age);
    }
    // 关闭文件
    fclose(file);
    // 打印结果
    Name: Alice, Age: 25
    Name: Bob, Age: 30
    Name: Charlie, Age: 22


node *table[N] = {NULL};
bool load(const char *dictionary)
{
    FILE *input = fopen(dictionary, "r");
    if (input == NULL)
    {
        return false;
    }

    char buffer[LENGTH + 1];
    while (fscanf(input, "%s", buffer) != EOF)
     {
        node *new_node = malloc(sizeof(node));
        if (new_node == NULL)
        {
            return false;
        }
        // 链表插法.
        strcpy(new_node->word, buffer);
        int num = hash(new_node->word);
        new_node->next = table(num);
        table(num) = new_node;
        Counter++;
     }
     fclose(input);
     return true;
}
