#include <cs50.h>
#include <stdio.h>

void print_row(int spaces, int bricks);
int main(void)
{

    int n = get_int("Height?");

    while (n < 1)
    {
        n = get_int("Height?");
    }
    for (int i = 0; i < n; i++) // 列 line
    {
        print_row(n - i, i + 1); // i+1使得变量bricks的值不断变大，从而实现每行的#依次不断增加。
        printf("\n");
    }
}

void print_row(int spaces, int bricks)
{
    for (int b = 0; b < spaces; b++)
    {
        printf(" "); // 空间解决了。
    }
    for (int a = 0; a < bricks; a++)
    {
        printf("#"); // 砖块解决了。
    }
}
