#include <cs50.h>
#include <stdio.h>

string card_number_type(long number);
bool luhn_check(long number);
int main(void)
{
    long card_number = get_long("card_number: "); // 输入卡号
    if (luhn_check(card_number))                  // 验证检验和。
    {
        printf("%s\n", card_number_type(card_number)); // 判断卡号类型。
    }
    else
    {
        printf("INVAILD\n");
    }
}

bool luhn_check(long number)
{
    int sum = 0;
    int digit = 0;
    bool alternate = false;
    while (number > 0)
    {
        digit = number % 10;
        if (alternate)
        {
            digit *= 2;
            if (digit > 9)
            {
                digit = digit / 10 + digit % 10;
            }
        }
        sum += digit;
        number /= 10;
        alternate = !alternate;
    }
    return sum % 10 == 0;
}

string card_number_type(long number)
{
    string type = "INVALID";
    int n = number / 100000000000000;
    if (number / 10000000000000 == 34 || number / 10000000000000 == 37)
    {
        type = "AMEX";
    }
    if (n > 51 && n <= 55)
    {
        type = "MASTERCARD";
    }
    if (number / 1000000000000 == 4 || number / 1000000000000000 == 4)
    {
        type = "VISA";
    }
    return type;
}
