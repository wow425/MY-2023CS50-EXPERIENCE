#include <stdio.h>
#include <stdbool.h>

char* card_number_type(long number);
bool luhn_check(long number);
int main(void)
{
    long card_number;
    printf("card_number: ");
    scanf("%li", &card_number);
    if (luhn_check(card_number))                  // 验证检验和。
    {
        printf("%s\n", card_number_type(card_number)); // 判断卡号类型。
    }
    else
    {
        printf("INVAILD\n");
    }
}

// bool luhn_check(long number)   // 卢恩算法
// {
//     int sum = 0;
//     int digit = 0;
//     bool alternate = false;
//     while (number > 0)
//     {
//         digit = number % 10;
//         if (alternate)
//         {
//             digit *= 2;
//             if (digit > 9)
//             {
//                 digit = digit / 10 + digit % 10;
//             }
//         }
//         sum += digit;
//         number /= 10;
//         alternate = !alternate;
//     }
//     return sum % 10 == 0;
// }

char* card_number_type(long number)
{
    char* type = "INVALID";
    int n = number / 100000000000000;
    if (number / 10000000000000 == 34 || number / 10000000000000 == 37)
    {
        type = "AMEX";
    }
    if (n >= 51 && n <= 55)
    {
        type = "MASTERCARD";
    }
    if (number / 1000000000000 == 4 || number / 1000000000000000 == 4)
    {
        type = "VISA";
    }
    return type;
}
