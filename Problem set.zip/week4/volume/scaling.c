#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>

const int headfile = 44;
int main(int argc, char *argv[])
{
    if (argc != 4)
    {
         printf("1");
        return 1;
    }
    FILE *input = fopen(argv[1], "r"); // notice lowercase
    if (input == NULL)
    {
        printf("2");
        return 2;
    }
    FILE *output = fopen(argv[2], "w");
    if (output == NULL)
    {
        printf("3");
        return 3;
    }
    float factor = atof(argv[3]);
    uint8_t buffer[headfile];
    // 数组名本身会隐式地转换为指向第一个元素的指针
    fread(buffer, headfile, 1, input);
    fwrite(buffer, headfile, 1, output);
    int16_t store;
    while (fread(&store, sizeof(int16_t), 1, input))
    {
        store *= factor;
        fwrite(&store, sizeof(int16_t), 1, output);
    }
    fclose(input);
    fclose(output);
}
