#include "helpers.h"
#include <math.h>

// Convert image to grayscale
void grayscale(int height, int width, RGBTRIPLE image[height][width])
{
    for (int i = 0; i < height; i++)
    {
        for (int n = 0; n < width; n++)
        {
            int r =  image[i][n].rgbtRed;
            int g =  image[i][n].rgbtGreen;
            int b =  image[i][n].rgbtBlue;
            int average = round((r + g + b) / 3.0);
            image[i][n].rgbtRed = average;
            image[i][n].rgbtGreen = average;
            image[i][n].rgbtBlue = average;
        }
    }
    return;
}

// Convert image to sepia
void sepia(int height, int width, RGBTRIPLE image[height][width])
{
    for (int i = 0; i < height; i++)
    {
        for (int n = 0; n < width; n++)
        {
            int sepiaRed = round(.393 * image[i][n].rgbtRed + .769 * image[i][n].rgbtGreen + .189 * image[i][n].rgbtBlue);
            if (sepiaRed > 255)
            {
                sepiaRed = 255;
            }
            int sepiaGreen = round(.349 * image[i][n].rgbtRed + .686 * image[i][n].rgbtGreen + .168 * image[i][n].rgbtBlue);
            if (sepiaGreen > 255)
            {
                sepiaGreen = 255;
            }
            int sepiaBlue = round(.272 * image[i][n].rgbtRed + .534 * image[i][n].rgbtGreen + .131 * image[i][n].rgbtBlue);
            if (sepiaBlue > 255)
            {
                sepiaBlue = 255;
            }
            image[i][n].rgbtRed = sepiaRed;
            image[i][n].rgbtGreen = sepiaGreen;
            image[i][n].rgbtBlue = sepiaBlue;
        }
    }
    return;
}

// Reflect image horizontally
void reflect(int height, int width, RGBTRIPLE image[height][width])
{
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width / 2; j++)
        {
            RGBTRIPLE temp = image[i][j];
            image[i][j] = image[i][width - 1 - j];
            image[i][width - 1 - j] = temp;
        }
    }
    return;
}

// Blur image
void blur(int height, int width, RGBTRIPLE image[height][width])
{
    // 副本复制
    RGBTRIPLE copy[height][width];
    for (int i = 0; i < height; i++)
    {
        for (int n = 0; n < width; n++)
        {
            copy[i][n] = image[i][n];
        }
    }
    // 盒子模糊算法
     //三行，分别是i-1,i,i+1.三列分别是n-1,n,n+1 从i - 1——> i + 1
    int i = 0, n = 0, Red = 0, Green = 0, Blue = 0;
    for (i = 0; i < height; i++) // 遍历行
    {
        for (n = 0; n < width; n++) // 遍历列
        {
            int Red_sum = 0, Green_sum = 0, Blue_sum = 0, pixel_sum = 0; // 注意变量作用域范围
            for (int prow = i - 1; prow <= i + 1; prow++) //3x3像素点检验，prow行，pcolumn列
            {
                for (int pcolumn = n - 1; pcolumn <= n + 1; pcolumn++)
                {
                    if (prow >= 0 && pcolumn >= 0 && prow < height && pcolumn < width)
                    {
                        Red_sum += copy[prow][pcolumn].rgbtRed;
                        Green_sum += copy[prow][pcolumn].rgbtGreen;
                        Blue_sum += copy[prow][pcolumn].rgbtBlue;
                        pixel_sum++;
                    }
                }
            } // 3x3像素点检验完毕
            Red = round(Red_sum / (float)pixel_sum);
            Green = round(Green_sum / (float)pixel_sum);
            Blue = round(Blue_sum / (float)pixel_sum);
            image[i][n].rgbtRed = Red;
            image[i][n].rgbtGreen = Green;
            image[i][n].rgbtBlue = Blue;
        }
    }
    return;
}
