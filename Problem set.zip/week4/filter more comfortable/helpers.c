
#include "helpers.h"
#include <math.h>

// Convert image to grayscale
void grayscale(int height, int width, RGBTRIPLE image[height][width])
{
    for (int i = 0; i < height; i++) //row
    {
        for (int n = 0; n < width; n++) //column
        {
            int R = image[i][n].rgbtRed;
            int G = image[i][n].rgbtGreen;
            int B = image[i][n].rgbtBlue;
            int average = round((R + G + B) / 3.0);
            image[i][n].rgbtRed = average;
            image[i][n].rgbtGreen = average;
            image[i][n].rgbtBlue = average;
        }
    }
    return;
}

// Reflect image horizontally
void reflect(int height, int width, RGBTRIPLE image[height][width])
{
    RGBTRIPLE buffer;
    for (int i = 0; i < height; i++) //row
    {
        for (int n = 0; n < width / 2; n++) //column
        {
             buffer.rgbtRed = image[i][n].rgbtRed;
             buffer.rgbtGreen = image[i][n].rgbtGreen;
             buffer.rgbtBlue = image[i][n].rgbtBlue;
             image[i][n].rgbtRed = image[i][width - n -1].rgbtRed;
             image[i][n].rgbtGreen = image[i][width - n - 1].rgbtGreen;
             image[i][n].rgbtBlue = image[i][width - n - 1].rgbtBlue;
             image[i][width - n- 1].rgbtRed = buffer.rgbtRed;
             image[i][width - n - 1].rgbtGreen = buffer.rgbtGreen;
             image[i][width - n - 1].rgbtBlue = buffer.rgbtBlue;
        }
    }
    return;
}

// Blur image
void blur(int height, int width, RGBTRIPLE image[height][width])
{
    RGBTRIPLE temparray[height][width];
    for (int i = 0; i < height; i++) //row
    {
        for (int n = 0; n < width; n++) //column
        {
            temparray[i][n] = image[i][n];
        }
    }
    for (int i = 0; i < height; i++) //row 像素点的行列
    {
        for (int n = 0; n < width; n++) //column
        {
            int pRsum = 0, pGsum = 0, pBsum = 0, sum = 0;
            for (int prow = i - 1; prow < i + 2; prow++) //3x3check的行列
            {
                for (int pcloumn = n - 1; pcloumn < n + 2; pcloumn++)
                {
                    if (pcloumn >= 0 && pcloumn < width && prow >= 0 && prow < height)
                    {
                    pRsum += temparray[prow][pcloumn].rgbtRed;
                    pGsum += temparray[prow][pcloumn].rgbtGreen;
                    pBsum += temparray[prow][pcloumn].rgbtBlue;
                    sum++;
                    }
                }
            }
            image[i][n].rgbtRed = round(pRsum / (float)sum);
            image[i][n].rgbtGreen = round(pGsum / (float)sum);
            image[i][n].rgbtBlue = round(pBsum / (float)sum);
        }
    }
    return;
}

// Detect edges
// 1.对每个像素点进行3X3的边缘检测
// 2.三通道分别计算出GX和GY，越出边界的像素点视作黑点处理
// 3.将GX平方 + GY平方的和开平方根，其值即为处理后的颜色通道值
void edges(int height, int width, RGBTRIPLE image[height][width])
{
    RGBTRIPLE temparray[height][width];
    for (int i = 0; i < height; i++) //row
    {
        for (int n = 0; n < width; n++) //column
        {
            temparray[i][n] = image[i][n];
        }
    } // 完成copy副本
    int Gx[3][3] = { {-1, 0 ,1},
                     {-2, 0, 2},
                     {-1, 0, 1} };
    int Gy[3][3] = { {-1,-2,-1},
                     {0, 0, 0},
                     {1, 2, 1} };
    for (int y = 0; y < height; y++) //row 像素点的行列
    {
        for (int x = 0; x < width; x++) //column
        {
            int GxRedsum = 0, GxGreensum = 0, GxBluesum = 0;
            int GyRedsum = 0, GyGreensum = 0, GyBluesum = 0;
            for (int py = -1; py <= 1; py++) //3x3check的行列
            {
                int newy = py + y;
                for (int px = -1; px <= 1; px++)
                {
                    int newx = px + x;
                    if (newy < 0 || newy >= height || newx < 0 || newx >= width)
                    {
                        continue; // 跳过当前循环体，进入下次循环迭代。
                    }
                    GxRedsum += temparray[newy][newx].rgbtRed * Gx[py + 1][px + 1];
                    GxGreensum += temparray[newy][newx].rgbtGreen * Gx[py + 1][px + 1];
                    GxBluesum += temparray[newy][newx].rgbtBlue * Gx[py + 1][px + 1];
                    GyRedsum += temparray[newy][newx].rgbtRed * Gy[py + 1][px + 1];
                    GyGreensum += temparray[newy][newx].rgbtGreen * Gy[py + 1][px + 1];
                    GyBluesum += temparray[newy][newx].rgbtBlue * Gy[py + 1][px + 1];
                }
            }
            // fmax取两数最大的，fmin取两数最小的。参数要浮点型，但编译器能隐式转换为浮点型。返回值为double型
            // sqrt square root 平方根 math.h库函数
            image[y][x].rgbtRed = (int)fmax(0, fmin(255, round(sqrt(GxRedsum * GxRedsum + GyRedsum * GyRedsum))));
            image[y][x].rgbtGreen = (int)fmax(0, fmin(255, round(sqrt(GxGreensum * GxGreensum + GyGreensum * GyGreensum))));
            image[y][x].rgbtBlue = (int)fmax(0, fmin(255, round(sqrt(GxBluesum * GxBluesum + GyBluesum * GyBluesum))));
        }
    }
    return;
}
